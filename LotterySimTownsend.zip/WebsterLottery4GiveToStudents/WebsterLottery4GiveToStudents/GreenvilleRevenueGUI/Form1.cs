﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//----------------------------------------
// Written By Charles Townsend
// COP2360 C# Programming I
// www.fsw.edu
// Dr. Roger Webster - Professor
// GiveToStudents Code
//----------------------------------------
namespace GreenvilleRevenueGUI
{
    public partial class Form1 : Form
    {
        Random ranNumberGenerator = new Random();

        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        int num4 = 0;
        int num5 = 0;
        int num6 = 0;

        int lottonum1 = 0;
        int lottonum2 = 0;
        int lottonum3 = 0;
        int lottonum4 = 0;
        int lottonum5 = 0;
        int lottonum6 = 0;

        int totalwinnings = 0;

        public Form1()
        {
            InitializeComponent();
            //preset the numbers!!!
            textBox1.Text = "1";
            textBox2.Text = "2";
            textBox3.Text = "3";
            textBox4.Text = "4";
            textBox5.Text = "5";
            textBox6.Text = "6";

            label6.Text = "";
        }

        public void DisplayMatchNumbers()
        {




        }

        public void FillInLottoTextBoxes()
        {
            outputLabel1.Text = "" + lottonum1;
            outputLabel2.Text = "" + lottonum2;
            outputLabel3.Text = "" + lottonum3;
            outputLabel4.Text = "" + lottonum4;
            outputLabel5.Text = "" + lottonum5;
            outputLabel6.Text = "" + lottonum6;
        }

        public void getUserNumbers()
        {
            num1 = Convert.ToInt32(textBox1.Text);
            num2 = Convert.ToInt32(textBox2.Text);
            num3 = Convert.ToInt32(textBox3.Text);
            num4 = Convert.ToInt32(textBox4.Text);
            num5 = Convert.ToInt32(textBox5.Text);
            num6 = Convert.ToInt32(textBox6.Text);
        }

        private int check_forDuplicates()
        {
            int randomNumber = 0;
            //creates a random number between 1 and 53

            Boolean dups = false;
            do
            {

                dups = false;
                randomNumber = ranNumberGenerator.Next(1, 54);
                if (randomNumber == lottonum1 || randomNumber == lottonum2 || randomNumber == lottonum3 || randomNumber == lottonum4 || randomNumber == lottonum5 || randomNumber == lottonum6)
                {
                    dups = true;
                }


            } while (dups);


            return randomNumber;
        }

        private int check_for_Winnings()
        {
            // This is the code to count the matches

            FillInLottoTextBoxes();
            int nummatches = 0;
            if (num1 == lottonum1 || num1 == lottonum2 || num1 == lottonum3 || num1 == lottonum4 || num1 == lottonum5 || num1 == lottonum6)
            {

                nummatches++;
                //Will Highlight if there is a match!
                PaintUserNumbersYellow(0);
            }
            if (num2 == lottonum1 || num2 == lottonum2 || num2 == lottonum3 || num2 == lottonum4 || num2 == lottonum5 || num2 == lottonum6)
            {

                nummatches++;
                PaintUserNumbersYellow(1);
            }
            if (num3 == lottonum1 || num3 == lottonum2 || num3 == lottonum3 || num3 == lottonum4 || num3 == lottonum5 || num3 == lottonum6)
            {

                nummatches++;
                PaintUserNumbersYellow(2);
            }
            if (num4 == lottonum1 || num4 == lottonum2 || num4 == lottonum3 || num4 == lottonum4 || num4 == lottonum5 || num4 == lottonum6)
            {

                nummatches++;
                PaintUserNumbersYellow(3);
            }
            if (num5 == lottonum1 || num5 == lottonum2 || num5 == lottonum3 || num5 == lottonum4 || num5 == lottonum5 || num5 == lottonum6)
            {

                nummatches++;
                PaintUserNumbersYellow(4);
            }
            if (num6 == lottonum1 || num6 == lottonum2 || num6 == lottonum3 || num6 == lottonum4 || num6 == lottonum5 || num6 == lottonum6)
            {

                nummatches++;
                PaintUserNumbersYellow(5);
            }

            return nummatches;
        }

        //---------------------------------------------------
        // GRAPHICS METHODS
        //---------------------------------------------------

        public void PaintUserNumbersYellow(int numi)
        {
            switch (numi)
            {
                case 0:
                    textBox1.BackColor = Color.Yellow;
                    textBox1.Refresh();
                    break;
                case 1:
                    textBox2.BackColor = Color.Yellow;
                    textBox2.Refresh();
                    break;
                case 2:
                    textBox3.BackColor = Color.Yellow;
                    textBox3.Refresh();
                    break;
                case 3:
                    textBox4.BackColor = Color.Yellow;
                    textBox4.Refresh();
                    break;
                case 4:
                    textBox5.BackColor = Color.Yellow;
                    textBox5.Refresh();
                    break;
                case 5:
                    textBox6.BackColor = Color.Yellow;
                    textBox6.Refresh();
                    break;
            }
        }
        public void ResetPaintNumbersYellow()
        {

            textBox1.BackColor = Color.White;
            textBox1.Refresh();

            textBox2.BackColor = Color.White;
            textBox2.Refresh();

            textBox3.BackColor = Color.White;
            textBox3.Refresh();

            textBox4.BackColor = Color.White;
            textBox4.Refresh();

            textBox5.BackColor = Color.White;
            textBox5.Refresh();

            textBox6.BackColor = Color.White;
            textBox6.Refresh();
        }

        private void Flamingobutton_Click(object sender, EventArgs e)
        {

            ResetPaintNumbersYellow();

            lottonum1 = check_forDuplicates();
            lottonum2 = check_forDuplicates();
            lottonum3 = check_forDuplicates();
            lottonum4 = check_forDuplicates();
            lottonum5 = check_forDuplicates();
            lottonum6 = check_forDuplicates();

            FillInLottoTextBoxes();

            getUserNumbers();

            int nummatches = check_for_Winnings();

            label5.Text = "The number of matches is: " + nummatches;
            // Switch Statements for Winning code
            switch (nummatches)
            {
                case 2:
                    label6.Text = "Free Ticket!";
                    break;
                case 3:
                    label6.Text = "You won $25!!!";
                    break;
                case 4:
                    label6.Text = "You Won $13,000!!!";
                    break;
                case 5:
                    label6.Text = "You won the Jackpot! Enjoy your\n$11,000,000!";
                    break;
                default:
                    label6.Text = "Better Luck Next Time Suckah!";
                    break;

            }

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

