import javax.swing.JOptionPane;
import java.util.Random;

// ***********************************************
// Written by: YOUR NAME
// For: COP 2800 Java Programming
// Where: FSW Computer Science Program www.fsw.edu
// Professor: Dr. Roger Webster
// GiveToStudents Code
// ***********************************************
public class Main {

	public static void main(String[] args) {
		Random rand = new Random();
		int num;
		String input = "N";
		String Answer = "";
		String[] phrases = { " It is certain.", "It is decidedly so.", "Without a doubt.", "Yes definitely.",
				"You may rely on it.", "As I see it, yes.", "Most likely.", "Outlook good.", "Yes.",
				"Signs point to yes.", "Reply hazy, try again.", "Ask again later.", "Better not tell you now.",
				"Cannot predict now.", "Concentrate and ask again.", "Don't count on it, Bub.", "My reply is no.",
				"My sources say no.", "Outlook not so good.", "Very doubtful." };
		boolean keepgoing = true;

		// while loop goes here

		while (keepgoing) {

			input = JOptionPane.showInputDialog("Ask the Magic 8 Ball your question");
			if (input == null) {
				keepgoing = false;
			} else {
				num = GetNextIndex(rand, phrases.length);
				Answer = "Magic 8 Ball Says: " + phrases[num];
				JOptionPane.showMessageDialog(null, Answer);
			}
			// end of the loop
		}
		System.exit(0);
	}

	// computes a random number between 0 and length
	public static int GetNextIndex(Random rand, int length) {
		final int min = 0;
		final int max = length - 1;
		int value = rand.nextInt((max - min) + 1) + min;
		return (value);
	}

}
